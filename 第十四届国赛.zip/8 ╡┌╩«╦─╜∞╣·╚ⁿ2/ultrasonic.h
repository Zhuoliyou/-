#ifndef _ULTRASONIC_H
#define _ULTRASONIC_H

extern unsigned int speed;
extern char jiaozhun;
void PCA_init();
unsigned char ultra_read();

#endif