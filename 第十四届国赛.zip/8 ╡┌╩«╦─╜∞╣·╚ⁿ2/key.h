#ifndef _KEY_H
#define _KEY_H

unsigned char get_key();

#endif