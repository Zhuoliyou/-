#include <STC15F2K60S2.H>
#include "onewire.h"
void DS18B20_convert()
{
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
}

unsigned int DS18B20_read()
{
	unsigned char HSB,LSB;
	unsigned int T;
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	LSB=Read_DS18B20();
	HSB=Read_DS18B20();
	T=HSB<<8|LSB;
	T>>=4;
	T=T*10+(LSB&0X0F)*0.0625*10;
	return T;
}