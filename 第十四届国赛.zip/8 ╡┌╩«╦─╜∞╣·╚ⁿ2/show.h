#ifndef _SHOW_H
#define _SHOW_H

void select_HC573(unsigned char channel);
void system_init();
void display(unsigned char i,j);
void display_point(unsigned char i,j);

#endif