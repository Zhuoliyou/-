#include <STC15F2K60S2.H>

unsigned char S8S9_count;
bit S8S9_flag;
unsigned char get_key()
{
	static unsigned char key_state=0;
	static unsigned char rem=0;
	unsigned char flag=0;
	unsigned char key_value=0;
	S8S9_flag=0;
	P32=P33=0;
	P44=P42=1;
	if(P44==0){flag=1;}
	else if(P42==0){flag=2;}
	P32=P33=1;
	P44=P42=0;
	if(P32==0){flag=flag;}
	else if(P33==0){flag+=2;}if(P32==0 && P33==0){S8S9_flag=1;}else {S8S9_flag=0;}
	switch(key_state)
	{
		case 0: 
			if(flag)
			{
				key_state=1;
			}
		break;
		case 1: 
			if(flag==0)
			{
				key_state=0;
			}
			else
			{
				key_state=2;
				rem=flag;
			}
		break;
		case 2: 
			if(S8S9_flag)
			{
				S8S9_flag=0;
				S8S9_count++;
			}
			if(flag==0)
			{
				switch(rem)
				{
					case 1: key_value=1; break;
					case 2: key_value=2; break;
					case 3: key_value=3; break;
					case 4: key_value=4; break;
				}
				if(S8S9_count>=180){key_value=5;S8S9_count=0;}
				else{S8S9_count=0;}
				key_state=0;
			}
		break;
	}
	return key_value;
}


