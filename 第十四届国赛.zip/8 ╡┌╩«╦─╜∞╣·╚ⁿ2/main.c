#include <STC15F2K60S2.H>
#include "show.h"
#include "key.h"
#include "ultrasonic.h"
#include "DS18B20.h"
#include "FPC8591.h"
unsigned int  T;
unsigned char distance;
unsigned char T_para=30;
unsigned char distance_para=40;
unsigned char show_state;
unsigned char DAC_low=10;
unsigned char dat;
unsigned char LED_temp;
unsigned char JDQ_temp;
unsigned char	S5_state3;//�����������л�F1 F2 F3
bit S5_state1;//��λ�л�
bit S5_state2;//�����������л�P1 P2

bit key_flag;
bit ultra_flag;
bit T_flag;
bit DAC_open;
bit DAC_flag;
bit S8_start;
bit LED_flash;
void show0()
{
	static unsigned char i;
	switch(i)
	{
		case 0: display(0,T/100);break;
		case 1: display_point(1,T/10%10);break;
		case 2: display(2,T%10);break;
		case 3: display(3,16);break;
		case 4: display(4,17);break;
		case 5: display(5,17);break;
		case 6: if(S5_state1==0)display(6,distance/10);else display_point(6,distance/100);break;
		case 7: if(S5_state1==0)display(7,distance%10);else display(7,distance/10%10);break;	
	}
	i++;
	i%=8;
}
void show1()
{
	static unsigned char i;
	if(S5_state2==0)
	{
		switch(i)
		{
			case 0: display(0,18);break;
			case 1: display(1,1);break;
			case 2: display(2,17);break;
			case 3: display(3,17);break;
			case 4: display(4,17);break;
			case 5: display(5,17);break;
			case 6: display(6,distance_para/10);break;
			case 7: display(7,distance_para%10);break;	
		}
	}
	else if(S5_state2)
	{
		switch(i)
		{
			case 0: display(0,18);break;
			case 1: display(1,2);break;
			case 2: display(2,17);break;
			case 3: display(3,17);break;
			case 4: display(4,17);break;
			case 5: display(5,17);break;
			case 6: display(6,T_para/10);break;
			case 7: display(7,T_para%10);break;	
		}
	}
	i++;
	i%=8;
}
void show2()  //����ģʽ
{
	static unsigned char i;
	if(S5_state3==0)
	{
		if(jiaozhun>=0)
		{
			switch(i)
			{
				case 0: display(0,15);break;
				case 1: display(1,1);break;
				case 2: display(2,17);break;
				case 3: display(3,17);break;
				case 4: display(4,17);break;
				case 5: display(5,17);break;
				case 6: if(jiaozhun>9)display(6,jiaozhun/10);break;
				case 7: if(jiaozhun>=0)display(7,jiaozhun%10);break;	
			}
		}
		else
		{
			switch(i)
			{
				case 0: display(0,15);break;
				case 1: display(1,1);break;
				case 2: display(2,17);break;
				case 3: display(3,17);break;
				case 4: display(4,17);break;
				case 5: if(-jiaozhun>9)display(5,16);else display(5,17);break;
				case 6: if(-jiaozhun>9)display(6,-jiaozhun/10);else display(6,16);break;
				case 7: display(7,-jiaozhun%10);break;	
			}
		}
		
	}
	else if(S5_state3==1)
	{
		switch(i)
		{
			case 0: display(0,15);break;
			case 1: display(1,2);break;
			case 2: display(2,17);break;
			case 3: display(3,17);break;
			case 4: if(speed>999)	display(4,speed/1000);break;
			case 5: if(speed>99)	display(5,speed/100%10);break;
			case 6: if(speed>9)		display(6,speed/10%10);break;
			case 7: if(speed>=0)	display(7,speed%10);break;	
		}
	}
	else if(S5_state3==2)
	{
		switch(i)
		{
			case 0: display(0,15);break;
			case 1: display(1,3);break;
			case 2: display(2,17);break;
			case 3: display(3,17);break;
			case 4: display(4,17);break;
			case 5: display(5,17);break;
			case 6: display_point(6,DAC_low/10);break;
			case 7: display(7,DAC_low%10);break;	
		}
	}
	i++;
	i%=8;
}
void show()
{
	if(show_state==0){show0();}
	else if(show_state==1){show1();}
	else if(show_state==2){show2();}
}
void Timer0Init(void)		//1����@12.000MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0x20;		//���ö�ʱ��ֵ
	TH0 = 0xD1;		//���ö�ʱ��ֵ
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	ET0=1;
	EA=1;
}
void LED()
{
	select_HC573(0);
	P0=~LED_temp;
	select_HC573(4);
	select_HC573(5);
	P0=JDQ_temp;
	select_HC573(0);
	
}
unsigned int  T_count;
unsigned char show_count;
unsigned char key_count;
unsigned char ultra_count;
unsigned char DAC_count;
unsigned int count;
void Timer0_routine() interrupt 1
{
	if(++show_count>=2)
	{
		show();
		LED();
		show_count=0;
	}
	if(++key_count>=11)
	{
		key_flag=1;
		key_count=0;
	}
	if(++T_count>=750)
	{
		T_flag=1;
		T_count=0;
	}
	if(++ultra_count>=101)
	{
		ultra_flag=1;
		ultra_count=0;
	}
	if(++DAC_count>=100)
	{
		DAC_flag=1;
		LED_flash=!LED_flash;
		DAC_count=0;
	}
	if(S8_start)
	{
		if(++count>=6000)
		{
			S8_start=0;
			count=0;
		}
	}
	else
	{
		count=0;
	}
}
void key_loop()
{
	unsigned char key_val;
	if(key_flag)
	{
		key_flag=0;
		key_val=get_key();
		switch(key_val)
		{
			case 3: //S4444444
				show_state++; show_state%=3;
				S5_state1=S5_state2=S5_state3=0;
			break;
			case 1: //S5555555
				if(show_state==0){S5_state1=!S5_state1;}
				else if(show_state==1){S5_state2=!S5_state2;}
				else if(show_state==2){S5_state3++;S5_state3%=3;}
			break;
			case 4: //S8888888
				if(show_state==0)
				{
					S8_start=1;
				}
				else if(show_state==1)
				{
					if(S5_state2==0 && distance_para<90){distance_para+=10;}
					else if(S5_state2==1 && T_para<80){T_para+=1;}
				}
				else if(show_state==2)
				{
					if(S5_state3==0 && jiaozhun<90){jiaozhun+=5;}
					else if(S5_state3==1 && speed<9990){speed+=10;}
					else if(S5_state3==2 && DAC_low<80){DAC_low+=1;}
				}
			break;
			case 2: //S9999999
				if(show_state==0 && T && dsitance)
				{
					DAC_open=1;
				}
				else if(show_state==1)
				{
					if(S5_state2==0 && distance_para>10){distance_para-=10;}
					else if(S5_state2==1 && T_para>0){T_para-=1;}
				}
				else if(show_state==2)
				{
					if(S5_state3==0 && jiaozhun>-90){jiaozhun-=5;}
					else if(S5_state3==1 && speed>10){speed-=10;}
					else if(S5_state3==2 && DAC_low>1){DAC_low-=1;}
				}
			break;
			case 5: 
				S5_state1=0;
				distance_para=40;
				T_para=30;
				speed=340;
				jiaozhun=0;
				DAC_low=10;
			
			break;
		}
	}
}
void DAC_output()
{
	if(distance>=90)
	{
		dat=255;
		FPC8591_DAC(dat);
	}
	else if(distance<=10)
	{
		dat=DAC_low/10.0*51;
		FPC8591_DAC(dat);
	}
	else
	{
		dat=(5*51.0-DAC_low*5.1)/80*distance+(DAC_low*0.9*51.0-5*51.0)/8;
		if(dat>255)dat=255;
		FPC8591_DAC(dat);
	}
}
void LED_work()
{
	if(show_state==0)
	{
		if(distance<255)
		{
			LED_temp=distance;
		}
		else
		{
			LED_temp=LED_temp&0x00|0xff;
		}
	}
	if(show_state==1)
	{
		LED_temp=LED_temp&0x00|0x80;
	}
	
	if(show_state==2 && LED_flash)
	{
		LED_temp=LED_temp&0x00|0x01;
	}
	else if(show_state==2 && LED_flash==0)
	{
		LED_temp=LED_temp&0x00;
	}
	if(distance>=(distance_para-5) && distance<=(distance_para+5))
	{
		JDQ_temp=JDQ_temp&0xef|0x10;
	}
	else
	{
		JDQ_temp=JDQ_temp&0xef;
	}
}
void main()
{
	system_init();
	DS18B20_convert();
	PCA_init();
	Timer0Init();
	while(1)
	{
		if(S8_start==0)key_loop();
		if(T_flag && S8_start){T_flag=0; T=DS18B20_read();DS18B20_convert();}
		if(ultra_flag && S8_start){ultra_flag=0; distance=ultra_read()+jiaozhun;}
		if(DAC_open && DAC_flag){DAC_flag=0;DAC_output();}
		LED_work();
	}
}