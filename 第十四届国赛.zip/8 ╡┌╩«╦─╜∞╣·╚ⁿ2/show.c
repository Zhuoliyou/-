#include <STC15F2K60S2.H>
code unsigned char smgduan[]={0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80,0x90, 0x88, 0x83, 0xc6, 0xa1, 0x86, 0x8e,0xbf,0xff,~0x73};//P
code unsigned char smgduan_point[]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};	
code unsigned char com[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
	
void select_HC573(unsigned char channel)
{
	switch(channel)
	{
		case 4: P2=P2&0X1F|0X80; break;
		case 5: P2=P2&0X1F|0XA0; break;
		case 6: P2=P2&0X1F|0XC0; break;
		case 7: P2=P2&0X1F|0XE0; break;
		case 0: P2=P2&0X1F|0X00; break;
	}
}
void system_init()
{
	select_HC573(4);
	P0=0Xff;
	select_HC573(5);
	P0=0X00;
}
void SMG_cls()
{
	select_HC573(6);
	P0=0Xff;
	select_HC573(7);
	P0=0Xff;
}
void display(unsigned char i,j)
{
	SMG_cls();
	select_HC573(6);
	P0=com[i];
	select_HC573(7);
	P0=smgduan[j];
}
void display_point(unsigned char i,j)
{
	SMG_cls();
	select_HC573(6);
	P0=com[i];
	select_HC573(7);
	P0=smgduan_point[j];
}


