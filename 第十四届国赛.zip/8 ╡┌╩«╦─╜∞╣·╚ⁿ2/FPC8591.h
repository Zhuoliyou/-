#ifndef _FPC8591_H
#define _FPC8591_H

void FPC8591_DAC(unsigned char dat);

#endif