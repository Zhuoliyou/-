#ifndef _DS18B20_H
#define _DS18B20_H

void DS18B20_convert();
unsigned int DS18B20_read();

#endif