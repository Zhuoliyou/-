#ifndef _FPC8591_H
#define _FPC8591_H

unsigned char FPC8591_RB2_read();
void FPC8591_DAC(unsigned char dat);
#endif

