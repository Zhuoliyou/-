#include <STC15F2K60S2.H>
#include "intrins.h"
sbit TX=P1^0;
sbit RX=P1^1;
void Delay14us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 39;
	while (--i);
}
void PCA_init()
{
	CMOD=0X00;
	CCON=0X00;
}

void send_wave()
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
	  TX=1;Delay14us();
		TX=0;Delay14us();
	}
}
unsigned char read_ultra()
{
	unsigned char distance;
	unsigned long time;
	CH=CL=0;
	send_wave();
	CR=1;
	while(RX==1&&CF==0);
	CR=0;
	if(CF)
	{
		CF=0;
		distance=0;
	}
	else
	{
		time=CH<<8|CL;
		distance=time*344/20000;
	}
	return distance;
}




