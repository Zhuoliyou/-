#ifndef _AT24C02_H
#define _AT24C02_H

void AT24C02_writte(unsigned char add,dat);
unsigned char AT24C02_read(unsigned char add);
void Delay5ms(void);
#endif

