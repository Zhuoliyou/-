/*writted by CXK*/
#include <STC15F2K60S2.H>
#include "show.h"
#include "key.h"
#include "FPC8591.h"
#include "ultrasonic.h"
#include "AT24C02.h"
unsigned int frequency;
unsigned char humidity;
unsigned char distance;
unsigned char frequency_para=90;//1.0LKHZ--12.0KHZ
unsigned char humidity_para=40; //10%����60%
unsigned char distance_para=3; //0.1m--1.2m
unsigned char show_state;
bit           S7_state;//Ƶ�ʵ�λ�ڲ��л�
bit           S6_state;//���뵥λ�л�
unsigned char S5_state;//���������ڲ��л�
unsigned char LED_temp;
unsigned char JDQ_temp;
unsigned char JDQ_num;
unsigned char DAC_num;
bit show_flag;
bit key_flag;
bit U_flag;
bit ultra_flag;
bit JDQ_flag=1;
bit LED_flash;
bit PWM_flag;
/*==========================================show===================================================*/
/*==========================================show===================================================*/
/*==========================================show===================================================*/
void show0()//Ƶ��Ƶ��Ƶ��Ƶ��Ƶ��Ƶ��Ƶ��
{
	static unsigned char i;
	if(S7_state==0)
	{
		switch(i)
		{
			case 0: display(0,15); break;
			case 1: display(1,17); break;
			case 2: display(2,17); break;
			case 3: if(frequency>9999)display(3,frequency/10000);   break;
			case 4: if(frequency>999) display(4,frequency/1000%10); break;
			case 5: if(frequency>99)  display(5,frequency/100%10);  break;
			case 6: if(frequency>9)   display(6,frequency/10%10);   break;
			case 7: if(frequency>=0)  display(7,frequency%10);      break;
		}
	}
	else
	{
		switch(i)
		{
			case 0: display(0,15); break;
			case 1: display(1,17); break;
			case 2: display(2,17); break;
			case 3: display(3,17);   break;
			case 4: display(4,17); break;
			case 5: if(frequency>9999)  display(5,frequency/10000);  break;
			case 6: display_point(6,frequency/1000%10);   break;
			case 7: display(7,frequency/100%10);      break;
		}
	}
	
	i++;
	i%=8;
}
void show1()//ʪ��ʪ��ʪ��ʪ��ʪ��ʪ��ʪ��
{
	static unsigned char i;
	switch(i)
	{
		case 0: display(0,19); break;
		case 1: display(1,DAC_num/100); break;
		case 2: display(2,DAC_num/10%10); break;
		case 3: display(3,DAC_num%10); break;
		case 4: display(4,17); break;
		case 5: display(5,17); break;
		case 6: if(humidity>9)   display(6,humidity/10%10);break;
		case 7: if(humidity>=0)  display(7,humidity%10); break;
	}
	i++;
	i%=8;
}
void show2()//�������������������������
{
	static unsigned char i;
	if(S6_state==0)
	{
		switch(i)
		{
			case 0: display(0,10); break;
			case 1: display(1,JDQ_num/10); break;
			case 2: display(2,JDQ_num%10); break;
			case 3: display(3,17); break;
			case 4: display(4,17); break;
			case 5: display(5,17); break;
			case 6: if(distance>9) display(6,distance/10%10);break;
			case 7: if(distance>=0) display(7,distance%10); break;
		}
	}
	else
	{
		switch(i)
		{
			case 0: display(0,10); break;
			case 1: display(1,17); break;
			case 2: display(2,17); break;
			case 3: display(3,17); break;
			case 4: display(4,17); break;
			case 5: display_point(5,distance/100); break;
			case 6: display(6,distance/10%10);break;
			case 7: display(7,distance%10); break;
		}
	}
	
	i++;
	i%=8;
}
void show3()//������������������������������������
{
	static unsigned char i;
	if(S5_state==0)
	{
		switch(i)
		{
			case 0: display(0,20); break;
			case 1: display(1,1);  break;
			case 2: display(2,17); break;
			case 3: display(3,17); break;
			case 4: display(4,17); break;
			case 5: if(frequency_para>99)display(5,frequency_para/100); break;
			case 6: display_point(6,frequency_para/10%10);break;
			case 7: display(7,frequency_para%10); break;
		}
	}
	else if(S5_state==1)
	{
		switch(i)
		{
			case 0: display(0,20); break;
			case 1: display(1,2);  break;
			case 2: display(2,17); break;
			case 3: display(3,17); break;
			case 4: display(4,17); break;
			case 5: display(5,17); break;
			case 6: display(6,humidity_para/10%10);break;
			case 7: display(7,humidity_para%10); break;
		}
	}
	else if(S5_state==2)
	{
		switch(i)
		{
			case 0: display(0,20); break;
			case 1: display(1,3);  break;
			case 2: display(2,17); break;
			case 3: display(3,17); break;
			case 4: display(4,17); break;
			case 5: display(5,17); break;
			case 6: display_point(6,distance_para/10%10);break;
			case 7: display(7,distance_para%10); break;
		}
	}
	
	i++;
	i%=8;
}
void show()
{
	if(show_state==0){show0();}
	else if(show_state==1){show1();}
	else if(show_state==2){show2();}
	else if(show_state==3){show3();}
}
/*==========================================show===================================================*/
/*==========================================show===================================================*/
/*==========================================show===================================================*/
void Timer_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x80;			//��ʱ��ʱ��1Tģʽ
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD  = 0x06;			//���ö�ʱ��ģʽ`
	
	TL0 = 0xff;				//���ö�ʱ��ʼֵ
	TH0 = 0xff;				//���ö�ʱ��ʼֵ
	TR0 = 1;				//��ʱ��0��ʼ��ʱ
	ET0 = 1;				//ʹ�ܶ�ʱ��0�ж�

	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	
	AUXR |= 0x04;			//��ʱ��ʱ��1Tģʽ
	T2L = 0x50;				//���ö�ʱ��ʼֵ
	T2H = 0xFB;				//���ö�ʱ��ʼֵ
	AUXR |= 0x10;			//��ʱ��2��ʼ��ʱ
	IE2 |= 0x04;			//ʹ�ܶ�ʱ��2�ж�

	EA=1;
}
void LED()
{
	select_HC573(0);
	P0=~LED_temp;
	select_HC573(4);
}
void JDQ()
{
	select_HC573(0);
	P0=JDQ_temp;
	select_HC573(5);
}
unsigned int count;
unsigned int count1;
void Timer0_Isr(void) interrupt 1
{
	count++;
}
unsigned char show_count;
unsigned char key_count;
unsigned char U_count;
unsigned char ultra_count;
void Timer1_Isr(void) interrupt 3
{
	if(++count1>=1000)
	{
		frequency=count;
		count=count1=0;
	}
	if(++show_count>=2)
	{
		show();
		LED();
		JDQ();
		show_count=0;
	}
	if(++key_count>=10)
	{
		key_flag=1;
		key_count=0;
	}
	if(++U_count>=111)
	{
		U_flag=1;
		LED_flash=!LED_flash;
		U_count=0;
	}
	if(++ultra_count>=222)
	{
		ultra_flag=1;
		ultra_count=0;
	}
}
unsigned char PWM_count;

void Timer2_Isr(void) interrupt 12 //0.1ms
{
	if(++PWM_count>=10)//����1ms  PWM:1KHZ
	{
	  PWM_count=0;
	}
	if(frequency>frequency_para*100)
	{
		if(PWM_count>=2)
		{
			PWM_flag=1;
		}
		else
		{
			PWM_flag=0;
		}
	}
	else
	{
		if(PWM_count>=8)
		{
			PWM_flag=1;
		}
		else
		{
			PWM_flag=0;
		}
	}
}

void key_loop()
{
	unsigned char key_val;
	if(key_flag)
	{
		key_flag=0;
		key_val=get_key();
		switch(key_val)
		{
			case 1: //S7
				if(show_state==0)S7_state=!S7_state;//Ƶ�ʵ�λ
				if(show_state==3)//��������
				{
					if(S5_state==0)
					{
						frequency_para-=5; if(frequency_para<10)frequency_para=120;
					}
					else if(S5_state==1)
					{
						humidity_para-=10; if(humidity_para<10)humidity_para=60;
					}
					else if(S5_state==2)
					{
						distance_para-=1; if(distance_para<1)distance_para=12;
					}
				}
			break;
			case 2: //S6
				if(show_state==2)S6_state=!S6_state;//���뵥λ
				if(show_state==3)//�ӼӼӼ�
				{
					if(S5_state==0)
					{
						frequency_para+=5; if(frequency_para>120)frequency_para=10;
					}
					else if(S5_state==1)
					{
						humidity_para+=10; if(humidity_para>60)humidity_para=10;
					}
					else if(S5_state==2)
					{
						distance_para+=1; if(distance_para>12)distance_para=1;
					}
				}
			break;
			case 3: //S5
				if(show_state==3)S5_state++;S5_state%=3;//�����л�
			break;
			case 4: //S4
				show_state++;show_state%=4;
				S5_state=S6_state=S7_state=0;
			break;
			case 5: //����
				if(show_state==1){JDQ_num=0;AT24C02_writte(0,JDQ_num);Delay5ms();}
			break;
		}
	}
}
void JDQ_trigger()
{
	if(distance>distance_para*10)
	{
		JDQ_temp=JDQ_temp&0xef|0x10;
		if(JDQ_flag)
		{
			JDQ_flag=0;
			JDQ_num++;
			AT24C02_writte(0,JDQ_num);Delay5ms();
		}
	}
	else
	{
		JDQ_temp=JDQ_temp&0xef;
		JDQ_flag=1;
	}
}
void LED_work()
{
	if(show_state==0 && LED_flash)
	{
		LED_temp=LED_temp&0xfe|0x01;
	}
	else
	{
		LED_temp=LED_temp&0xfe;
	}
	
	if(show_state==1 && LED_flash)
	{
		LED_temp=LED_temp&0xfd|0x02;
	}
	else
	{
		LED_temp=LED_temp&0xfd;
	}
	
	if(show_state==2 && LED_flash)
	{
		LED_temp=LED_temp&0xfb|0x04;
	}
	else
	{
		LED_temp=LED_temp&0xfb;
	}
	
	if(frequency>frequency_para*1000)
	{
		LED_temp=LED_temp&0xf7|0x08;
	}
	else
	{
		LED_temp=LED_temp&0xf7;
	}
	
	if(humidity>humidity_para)
	{
		LED_temp=LED_temp&0xef|0x10;
	}
	else
	{
		LED_temp=LED_temp&0xef;
	}
	
	if(distance>distance_para*10)
	{
		LED_temp=LED_temp&0xdf|0x20;
	}
	else
	{
		LED_temp=LED_temp&0xdf;
	}
}
 void DAC_output()
{
		if(humidity>=80)
		{
			DAC_num=255;
			FPC8591_DAC(DAC_num);
		}
		else if(humidity<=humidity_para)
		{
			DAC_num=51;
			FPC8591_DAC(DAC_num);
		}
		else
		{
			DAC_num=4*51.0*humidity/(80-humidity_para)+(80*51.0-5*51.0*humidity_para)/(80-humidity_para);
			FPC8591_DAC(DAC_num);
		}	
}
void MOTOR_output()
{
	if(PWM_flag)
	{
		select_HC573(5);
		P0=P0&0xdf|0x20;
		select_HC573(0);
	}
	else
	{
		select_HC573(5);
		P0=P0&0xdf;
		select_HC573(0);
	}
}
void main()
{
	system_init();
	PCA_init();
	JDQ_num=AT24C02_read(0);
	Timer_Init();
	while(1)
	{
		key_loop();
		if(U_flag){U_flag=0;humidity=FPC8591_RB2_read()*20/51.5;DAC_output();}
		if(ultra_flag){ultra_flag=0;distance=read_ultra();}
		JDQ_trigger();
		LED_work();
		MOTOR_output();
	}
}