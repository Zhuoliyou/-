#ifndef _ULTRASONIC_H
#define _ULTRASONIC_H

void PCA_init();
void send_wave();
unsigned char read_ultra();

#endif