#include <STC15F2K60S2.H>
#include "iic.h"

unsigned char FPC8591_RB2_read()
{
	unsigned char U,i;
	for(i=0;i<2;i++)
	{
		I2CStart();
		I2CSendByte(0x90);
		I2CWaitAck();
		I2CSendByte(0x03);
		I2CWaitAck();
	//  I2CStop();
		
		I2CStart();
		I2CSendByte(0x91);
		I2CWaitAck();
		U=I2CReceiveByte();
		I2CSendAck(1);
		I2CStop();
	}
	
	return U;
}
void FPC8591_DAC(unsigned char dat)
{
	I2CStart();
	I2CSendByte(0x90);
	I2CWaitAck();
	I2CSendByte(0x40);
	I2CWaitAck();
	I2CSendByte(dat);
	I2CWaitAck();
	I2CStop();
}